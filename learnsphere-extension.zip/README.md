# 🚀 LearnSphere: AI-Powered Learning Assistant

**LearnSphere** is an AI-powered Chrome extension designed to transform your study sessions. It acts as a personal learning assistant, helping you comprehend complex text, generate summaries, and test your knowledge directly from any webpage or PDF.

## ✨ Key Features

* **Contextual AI Chat**: Select any text on a page and start a conversation with the AI to get explanations, ask follow-up questions, or dive deeper into the topic.

* **📝 On-the-Fly Summaries**: Instantly generate concise summaries of long articles or selected text to grasp key points quickly.

* **🧠 Interactive Quiz Generation**: Create quizzes from any text to test your comprehension and reinforce your learning.

* **🖱️ Seamless Context Menu Integration**: Access all features with a simple right-click on selected text.

* **📊 Knowledge Gap Analysis**: The extension intelligently tracks your quiz performance to identify weak areas, suggesting topics and pages for revision.

* **⚙️ Extensive Customization**: Tailor the extension to your needs via a detailed settings page, including theme, AI parameters, quiz settings, accessibility options, and more.

* **🔒 Privacy-Focused**: Full control over your data with options for import, export, and complete data deletion. All AI processing requires your personal API key.

## 🛠️ How It Works

LearnSphere uses a service worker (`background.js`) to manage context menus and inject a powerful content script (`content.js`) into web pages. When you interact with a selection, the content script displays a sidebar UI built with React. This UI communicates with the Google Gemini API using your private API key to provide AI-driven features. All user data, such as quiz results and analytics, is stored locally in your browser's IndexedDB.

## ⚙️ Setup & Installation

### Step 1: Install the Extension

1. Download or clone this repository to your local machine.

2. Open Google Chrome and navigate to `chrome://extensions`.

3. Enable **"Developer mode"** using the toggle in the top-right corner.

4. Click the **"Load unpacked"** button.

5. Select the directory where you saved the extension files.

### Step 2: Configure Your API Key

LearnSphere requires a Google Gemini API key to function.

1. Click on the LearnSphere extension icon in your browser toolbar to open the popup.

2. Obtain a free API key from [**Google AI Studio**](https://makersuite.google.com/app/apikey).

3. Copy the API key, paste it into the input field in the extension popup, and click **"Save API Key"**.

4. The extension will test the key. Once validated, the AI features will be enabled.

## 📖 How to Use

Once installed and configured, using LearnSphere is simple:

1. **Navigate** to any webpage or open a PDF in Chrome.

2. **Select** a piece of text you want to work with.

3. **Right-click** on the selected text.

4. Hover over the **"🚀 LearnSphere"** menu and choose an option:

   * **💬 Chat about this**: Opens the sidebar to ask questions about the selection.

   * **📝 Generate Summary**: Creates a summary of the text in the sidebar.

   * **🧠 Create Quiz**: Generates an interactive quiz based on the text.

   * **🚀 Open LearnSphere Sidebar**: Opens the sidebar manually.

## 🔧 Configuration Options

The extension features a comprehensive options page where you can customize almost every aspect of your experience. To access it, right-click the extension icon and select "Options" or click the "Open Settings" button in the popup.

* **General**: Set the theme (Light/Dark/Auto) and language.

* **AI Settings**: Configure your Gemini API Key, max response tokens, and temperature (creativity).

* **Quiz Settings**: Set default quiz difficulty, question count, and toggle hints/explanations.

* **Chat Settings**: Adjust the sidebar position (left/right) and width.

* **Privacy & Data**: Manage learning analytics, data retention period, and import/export or clear all your data.

* **Accessibility**: Enable high-contrast mode, large text, or reduce motion.

## 💻 Technology Stack

* **Framework**: React

* **Browser API**: Chrome Extension Manifest V3

* **Local Storage**: IndexedDB with Dexie.js for robust client-side storage.

* **AI**: Google Gemini API (`gemini-1.5-flash` model).

* **Styling**: Plain CSS with a focus on clean, modern design.

## ⚖️ License

This project is licensed under the MIT License. See the `options.js.LICENSE.txt` file for details on the licenses of included libraries like React.